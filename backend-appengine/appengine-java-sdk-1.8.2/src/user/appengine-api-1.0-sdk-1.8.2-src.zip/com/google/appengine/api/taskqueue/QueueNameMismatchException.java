// Copyright 2010 Google Inc. All rights reserved.
package com.google.appengine.api.taskqueue;

/**
 * Queue name mismatch failure.
 *
 */
public class QueueNameMismatchException extends RuntimeException {
  public QueueNameMismatchException(String detail) {
    super(detail);
  }
}
